#include "ConfigUtils.h"
#include "external/json.hpp"
#include <codecvt>
#include <locale>
#include <fstream>
#include <iostream>
#include <algorithm>

using json = nlohmann::json;

std::string wstring_to_utf8(const std::wstring& wstr) {
    std::wstring_convert<std::codecvt_utf8<wchar_t>> conv;
    return conv.to_bytes(wstr);
}

std::wstring utf8_to_wstring(const std::string& str) {
    std::wstring_convert<std::codecvt_utf8<wchar_t>> conv;
    return conv.from_bytes(str);
}

std::wstring normalize_dash(const std::wstring& input) {
    std::wstring result = input;
    std::replace(result.begin(), result.end(), L'\u2014', L'-');
    std::replace(result.begin(), result.end(), L'\u2013', L'-');
    return result;
}

bool load_config(const std::string& filename,
                 std::vector<std::wstring>& out_files,
                 std::vector<std::wstring>& out_queries) {
    std::ifstream ifs(filename);
    if (!ifs.is_open()) {
        std::wcerr << L"Cannot open config file: " << utf8_to_wstring(filename) << L"\n";
        return false;
    }

    json j;
    try {
        ifs >> j;
        if (j.contains("files") && j["files"].is_array()) {
            for (auto& f : j["files"]) {
                out_files.push_back(utf8_to_wstring(f.get<std::string>()));
            }
        }
        if (j.contains("requests") && j["requests"].is_array()) {
            for (auto& q : j["requests"]) {
                out_queries.push_back(utf8_to_wstring(q.get<std::string>()));
            }
        }
    } catch (const std::exception& e) {
        std::wcerr << L"Error parsing config.json: " << utf8_to_wstring(e.what()) << L"\n";
        return false;
    }

    return true;
}

bool save_config(const std::string& filename,
                 const std::vector<std::wstring>& files,
                 const std::vector<std::wstring>& queries) {
    json j;
    std::vector<std::string> files_utf8;
    for (const auto& f : files) {
        files_utf8.push_back(wstring_to_utf8(f));
    }
    std::vector<std::string> queries_utf8;
    for (const auto& q : queries) {
        queries_utf8.push_back(wstring_to_utf8(q));
    }
    j["files"] = files_utf8;
    j["requests"] = queries_utf8;

    std::ofstream ofs(filename);
    if (!ofs.is_open()) {
        std::wcerr << L"Cannot open config file for writing: " << utf8_to_wstring(filename) << L"\n";
        return false;
    }
    ofs << j.dump(4);
    return true;
}
